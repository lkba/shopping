<?php
namespace Home\Controller;
use Think\Controller;
class CommonController extends Controller {
	protected $userInfo = false;  //用户登录信息（未登录为false）
	//构造方法
	public function __construct() {
		parent::__construct();
		//登录检查
		$this->checkUser();
	}
	//检查登录
	private function checkUser(){
		if(session('?username')){
			$userinfo = array(
				'username' => session('username'),  //用户名
				'tid' => session('tid'),  //用户名
			);
			$this->userInfo = $userinfo;    //保存登录后的信息
			$tid = $this->userInfo['tid'];
			$m = D('basic_infor');
			$logo = $m->field('logo')->where("tid=$tid")->find();
			$is_pass = M('user')->field('is_pass')->where("tid=$tid")->find();	
			$this->assign($logo);
			$this->assign($is_pass);
			$this->assign($userinfo);     //为模板分配用户信息变量
		}else{
			$this->error('请登陆',U('Login/index'));
		}
	}
	/**
	 * 公共数据创建方法
	 * @param string $tablename 表名
	 * @param string $func 操作方法
	 * @param int $type 验证时机
	 * @param string/array $where 查询条件
	 * @return mixed 操作结果
	 */
	protected function create($tablename,$func,$type='',$where=array()){
		$Model = D($tablename);
		if(!$Model->create(I('post.'),$type)){
			$this->error($Model->getError());
		}
		if(empty($where)){
			return $Model->$func();
		}
		return $Model->where($where)->$func();
	}
}