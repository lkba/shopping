<?php
namespace Home\Controller;
class MatchController extends CommonController{
	//构造方法
	public function __construct() {
		parent::__construct();
		$tid = $this->userInfo['tid'];
		$is_pass = M('user')->field('is_pass')->where("tid=$tid")->find();	
		if($is_pass['is_pass']!=1){
			$this->error('非法操作');
		}
	}
	public function index(){
		$m = D('match');
		$data = $m->getMatchs();
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
	public function show(){
		$tid = $this->userInfo['tid'];
		$id = I('get.id');
		$m = D('match');
		$data['match'] = $m->getMatch($id);
		
		$data['is_join'] = D('match')->is_join($tid,$id);
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
	//报名status
	public function join(){
		$tid = $this->userInfo['tid'];
		$id = I('get.mid');
		$status=M('match')->where("id=".$id." and status='yes'")->find();
		if(!$status){
		    $this->ajaxReturn(array('msg'=>'报名通道已关闭！'));         
	    }
		$m=M('match_actor');
		$t=$m->where("mid=".$id." and tid=".$tid)->find();
		if(!$t){
			$name=M('basic_infor')->where("tid=".$tid)->field('team')->find();
			if(empty($name['team']) || $name['team']==''){
				return $this->ajaxReturn(array('msg'=>'报名失败！请完善团队信息！'));    				
		    }
	        $data = array('tid'=>$tid, 'mid'=>$id, 'tname'=>$name['team']);
			$rst = $m->add($data);
			//返回结果
			if($rst==false){
				$this->ajaxReturn(array('msg'=>'报名失败！'));    				
		    }else{
		    	$this->ajaxReturn(array('flag'=>true)); 	        
		    }				
	   	}else{
		    $this->ajaxReturn(array('msg'=>'已报名！'));         
	    }
	}	
}