<?php
namespace Home\Model;
use Think\Model;
class NewsModel extends Model {	
	//得到新闻信息
    public function getNews($tid)
    {
        $lists = $this->table('news_many nm, news_manypop nmp')->where('nm.id=nmp.nid and tid='.$tid)->field('nm.id as id, nm.content as content, nm.date as date,nm.type as type,nmp.tid as tid ,nmp.is_read as is_read')->order('nm.id desc')->select();
        //查询数据
		$count = count($lists);
		$Page = new \Think\Page($count,5);
		$limit = $Page->firstRow.','.$Page->listRows;
		//取得数据
		$data['page'] = $Page->show();
		
		$sql = "SELECT nm.id as id,nm.content as content,nm.date as date,nm.type as type,nmp.tid as tid,nmp.is_read as is_read FROM news_many nm,news_manypop nmp 
		WHERE ( nm.id=nmp.nid and tid=$tid ) 
		ORDER BY nm.id desc
		limit $limit";
		$data['list'] = $this->query($sql);
		return $data;
    }
	
}