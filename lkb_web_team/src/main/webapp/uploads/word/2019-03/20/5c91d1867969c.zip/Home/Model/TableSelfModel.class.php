<?php
namespace Home\Model;
use Think\Model;
class TableSelfModel extends Model {
	//得到信息
    public function getList($tid)
    {
        //查询数据
		$count = $this->where('tid = '.$tid)->count();
		$Page = new \Think\Page($count,5);
		$limit = $Page->firstRow.','.$Page->listRows;
		//取得数据
		$data['pn']=$Page->firstRow/5+1;
		$data['page'] = $Page->show();
		
		$sql = "SELECT * FROM table_self
		WHERE (tid = $tid) 
		ORDER BY sid desc
		limit $limit";
		$data['data'] = $this->query($sql);
		return $data;
    }
}