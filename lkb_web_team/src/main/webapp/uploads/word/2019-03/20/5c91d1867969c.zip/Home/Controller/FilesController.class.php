<?php
namespace Home\Controller;
use Org\Net\Http;
class FilesController extends CommonController{
	//构造方法
	public function __construct() {
		parent::__construct();
		$tid = $this->userInfo['tid'];
		$is_pass = M('user')->field('is_pass')->where("tid=$tid")->find();	
		if($is_pass['is_pass']!=1){
			$this->error('非法操作');
		}
	}
	public function index(){
		$tid = $this->userInfo['tid'];
		//var_dump($data);
		//$this->assign($data);
		$this->display();
	}

	//上传资料
	public function uploadb(){
		$tid = $this->userInfo['tid'];	
		if($tid==''){//如果id为空 
            $this->error('请登录！','',1); 
        } 
  		//保存上传文件
		if(!empty($_FILES['cont']['name'])){
			$rst = D('table_enter')->uploadData($tid);
			if($rst===true){
				return  $this->success("上传成功","uploadb/c/success",1);
			}else{
				echo $rst;
			}
		}
		$this->display();
	}
    //下载计划书
    public function down()
    {
        $tid = $this->userInfo['tid'];
        if($tid==''){//如果id为空 
            $this->error('下载失败！','',1); 
        } 
        $file = M('table_enter')->where("tid=$tid")->getField("data");
        $team = M('basic_infor')->where("tid=$tid")->getField("team");
        if($team==''){//
            $team="data";
        }
        if ($file != "") {
            $data['files'] = $this->download("./Public/uploads/data/$file", "$team");
        } else {
        	$this->error('文件不存在','',2);
            //echo "文件不存在";
            exit();
        }

    }

    public function download($file, $name = '')
    {
        $fileName = $name ? $name : pathinfo($file, PATHINFO_FILENAME);
        $filePath = realpath($file);
        $fp = fopen($filePath, 'rb');

        if (!$filePath || !$fp) {
            header('HTTP/1.1 404 Not Found');
            echo "Error: 404 Not Found.(server file path error)<!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding -->";
            exit;
        }
        $fileName = $fileName . '.' . pathinfo($filePath, PATHINFO_EXTENSION);
        $encoded_filename = urlencode($fileName);
        $encoded_filename = str_replace("+", "%20", $encoded_filename);

        header('HTTP/1.1 200 OK');
        header("Pragma: public");
        header("Expires: 0");
        header("Content-type: application/octet-stream");
        header("Content-Length: " . filesize($filePath));
        header("Accept-Ranges: bytes");
        header("Accept-Length: " . filesize($filePath));

        $ua = $_SERVER["HTTP_USER_AGENT"];
        if (preg_match("/MSIE/", $ua)) {
            header('Content-Disposition: attachment; filename="' . $encoded_filename . '"');
        } else if (preg_match("/Firefox/", $ua)) {
            header('Content-Disposition: attachment; filename*="utf8\'\'' . $fileName . '"');
        } else {
            header('Content-Disposition: attachment; filename="' . $fileName . '"');
        }

        ob_end_clean();
        // 输出文件内容
        fpassthru($fp);
        exit;
    } 
}