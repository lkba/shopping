<?php
namespace Home\Controller;
class TeamController extends CommonController{
	//构造方法
	public function __construct() {
		parent::__construct();
		$tid = $this->userInfo['tid'];
		$is_pass = M('user')->field('is_pass')->where("tid=$tid")->find();	
		if($is_pass['is_pass']!=1){
			$this->error('非法操作');
		}
	}
	public function index(){
		$tid = $this->userInfo['tid'];
		$m = D('user');
		$data["basic"] = $m->getbList($tid);
		$data["user"] = $m->getuList($tid);
		$data["teacher"] = $m->gettList($tid);
		$data["team"] = $m->getteamList($tid);
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
	public function team(){
		$tid = $this->userInfo['tid'];
		$m = D('user');
		$data["basic"] = $m->getbList($tid);
		$data["user"] = $m->getuList($tid);
		$data["teacher"] = $m->gettList($tid);
		$data['len'] = count($data["teacher"])*2;
		$data["team"] = $m->getteamList($tid);
		$data['len2'] = count($data["team"])+1;
		$data['enter'] = $m->geteList($tid);
		$data['enter'][0]['thinking']=htmlspecialchars_decode($data['enter'][0]['thinking']);
		if(empty($data["teacher"])){
			$data["teacher"][0]['name']='无';
			$data["teacher"][0]['department']='无';
			$data["teacher"][0]['position']='无';
			$data["teacher"][0]['field']='无';
			$data['len'] = 2;
		}
		if(empty($data["team"])){
			$data["team"][0]['name']='无';
			$data["team"][0]['sex']='无';
			$data["team"][0]['department']='无';
			$data["team"][0]['professional']='无';
			$data["team"][0]['phone']='无';
			$data["team"][0]['email']='无';
			$data['len2'] = 2;
		}
		//var_dump($data["team"]);
		$this->assign($data);
		$this->display();
	}
	public function edit(){
		$tid = $this->userInfo['tid'];
		$m = D('user');
		$data["basic"] = $m->getbList($tid);
		$data["user"] = $m->getuList($tid);
		$data["teacher"] = $m->gettList($tid);
		$data['len'] = count($data["teacher"])*2+2;
		$data["team"] = $m->getteamList($tid);
		$data['len2'] = count($data["team"])+2;
		$data['enter'] = $m->geteList($tid);
		$data['tid'] = $tid;
		$data['enter'][0]['thinking']=htmlspecialchars_decode($data['enter'][0]['thinking']);
		//var_dump($data);
		//处理表单
		if (IS_POST){
			$this->reviseAction($tid);
			return;
		}
		
		$this->assign($data);
		$this->display();
	}
	//修改-处理表单
	private function reviseAction($tid){		
		$data = I('post.','','trim');
		//var_dump($data);
		//exit();
		$r1 = M('basic_infor')->where(array('tid'=>$tid))->count();
		//修改基本信息
		if($r1==0){
			$rst = $this->create('basic_infor','add',1,array("tid=$tid"));
			$data_tid = array('tid'=>$tid);
			M("basic_infor")->where("id=$rst")->setField($data_tid);
		}else{
			$rst = $this->create('basic_infor','save',2,array("tid=$tid"));
		}
		
		
		//修改老师信息
		$teacher = M("teacher"); // 实例化User对象
		foreach($data['id'] as $key => $v){
			if($v=='add'){
				$data2 = array('name'=>$data['name'][$key],'department'=>$data['department'][$key],'position'=>$data['position'][$key],'field'=>$data['field'][$key],'tid'=>$tid);
				$teacher->add($data2);	
			}else{
				$id = $data['id'][$key];
				$data2 = array('name'=>$data['name'][$key],'department'=>$data['department'][$key],'position'=>$data['position'][$key],'field'=>$data['field'][$key]);
				$teacher-> where("id=$id")->setField($data2);
			}				
		}
		
		//修改负责人信息
		$user = M("user");
		$data3 = array('name'=>$data['fname'],'age'=>$data['fage'],'sex'=>$data['fsex'],'department'=>$data['fdepartment'],'professional'=>$data['fprofessional'],'phone'=>$data['fphone'],'email'=>$data['femail']);
		$user->where("tid=$tid")->setField($data3);
		
		//修改成员信息
		$teammate = M("teammate");
		foreach($data['mateid'] as $key => $v){
			if($v=='add'){
				$data4 = array('name'=>$data['tname'][$key],'sex'=>$data['tsex'][$key],'department'=>$data['tdepartment'][$key],'professional'=>$data['tprofessional'][$key],'phone'=>$data['tphone'][$key],'email'=>$data['temail'][$key],'tid'=>$tid);
				$teammate->add($data4);	
			}else{
				$mateid = $data['mateid'][$key];
				$data4 = array('name'=>$data['tname'][$key],'sex'=>$data['tsex'][$key],'department'=>$data['tdepartment'][$key],'professional'=>$data['tprofessional'][$key],'phone'=>$data['tphone'][$key],'email'=>$data['temail'][$key]);
				$teammate->where("id=$mateid")->setField($data4);
			}		
		}
		
		$r2 = M('table_enter')->where(array('tid'=>$tid))->count();
		//修改其他信息、
		if($r2==0){
			$rst2 = $this->create('table_enter','add',1);
			$data_tid = array('tid'=>$tid);
			M("table_enter")->where("eid=$rst2")->setField($data_tid);
		}else{
			$rst2 = $this->create('table_enter','save',2,array("tid=$tid"));
		}
		$enter = M("table_enter");
		$data5 = array('money'=>$data['qmoney']);
		$enter->where("tid=$tid")->setField($data5);
		if($rst2===false){
			$this->error("修改其他信息失败！");
		}
				
		//跳转
		$this->redirect('Team/edit/s/success');
	}
	//导师删除
	public function teacherdel(){
		$tid = $this->userInfo['tid'];
		$id = I('get.id',0,'int');
		$teacher= M('teacher');

		//删除
		$rst = $teacher->where("id=$id and tid=$tid")->delete();
		//返回结果
		$this->ajaxReturn(array('flag'=>true));
	}

	//成员删除
	public function teamdel(){
		$tid = $this->userInfo['tid'];
		$id = I('get.id',0,'int');
		$teammate= M('teammate');

		//删除
		$rst = $teammate->where("id=$id and tid=$tid")->delete();
		//返回结果
		$this->ajaxReturn(array('flag'=>true));
	}

	//上传计划书
	public function uploadb(){
		$tid = $this->userInfo['tid'];	
		if($tid==''){//如果id为空 
            $this->error('请登录！','',1); 
        } 
  		//保存上传文件
		if(!empty($_FILES['cont']['name'])){
			$rst = D('table_enter')->upload($tid);
			//exit();
			if($rst===true){
				return  $this->redirect('Team/uploadb/c/success');
			}else{
				echo $rst;
			}
		}
		$this->display();
	}
    //下载计划书
    public function down()
    {
        $tid = $this->userInfo['tid'];
        if($tid==''){//如果id为空 
            $this->error('下载失败！','',1); 
        } 
        $file = M('table_enter')->where("tid=$tid")->getField("prospectus");
        $team = M('basic_infor')->where("tid=$tid")->getField("team");
        if($team==''){//
            $team="jihuashu";
        }
        if ($file != "") {
            $data['files'] = $this->download("./Public/uploads/word/$file", "$team");
        } else {
            echo "文件不存在";
            exit();
        }

    }

    public function download($file, $name = '')
    {
        $fileName = $name ? $name : pathinfo($file, PATHINFO_FILENAME);
        $filePath = realpath($file);
        $fp = fopen($filePath, 'rb');

        if (!$filePath || !$fp) {
            header('HTTP/1.1 404 Not Found');
            echo "Error: 404 Not Found.(server file path error)<!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding --><!-- Padding -->";
            exit;
        }
        $fileName = $fileName . '.' . pathinfo($filePath, PATHINFO_EXTENSION);
        $encoded_filename = urlencode($fileName);
        $encoded_filename = str_replace("+", "%20", $encoded_filename);

        header('HTTP/1.1 200 OK');
        header("Pragma: public");
        header("Expires: 0");
        header("Content-type: application/octet-stream");
        header("Content-Length: " . filesize($filePath));
        header("Accept-Ranges: bytes");
        header("Accept-Length: " . filesize($filePath));

        $ua = $_SERVER["HTTP_USER_AGENT"];
        if (preg_match("/MSIE/", $ua)) {
            header('Content-Disposition: attachment; filename="' . $encoded_filename . '"');
        } else if (preg_match("/Firefox/", $ua)) {
            header('Content-Disposition: attachment; filename*="utf8\'\'' . $fileName . '"');
        } else {
            header('Content-Disposition: attachment; filename="' . $fileName . '"');
        }

        ob_end_clean();
        // 输出文件内容
        fpassthru($fp);
        exit;
    } 
	//上传logo
	public function upload()
    {  
    	$tid = $this->userInfo['tid'];
  		//保存上传文件
		if(!empty($_FILES['thumb']['name'])){
			$rst = D('basic_infor')->uploadThumb($tid);
			if($rst==false){
				echo false;
			}else{
				return $this->ajaxReturn($rst);
			}
		}
    }
}