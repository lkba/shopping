<?php
namespace Home\Model;
use Think\Model;
class MatchModel extends Model {
	//得到比赛信息
    public function getMatchs()
    {
        //查询数据
		$count = $this->table('`match` m, match_picture mp')
        			->where('m.id=mp.mid and m.is_best="yes"')
        			->order('release_time desc')
        			->count();
		$Page = new \Think\Page($count,5);
		$limit = $Page->firstRow.','.$Page->listRows;
		//取得数据
		$data['page'] = $Page->show();
		
		$sql = "SELECT m.id,m.title,m.host_time,mp.thumb,mp.describe FROM `match` m, match_picture mp 
		WHERE (m.id=mp.mid and m.is_best='yes') 
		ORDER BY release_time desc
		limit $limit";
		$data['match'] = $this->query($sql);
		return $data;
    }
    //得到比赛信息
    public function getMatch($id)
    {
        $match = $this->table('match')
        		->where('is_best="yes" and id='.$id)
        		->find();
        return $match;
    }
	//是否参与
	public function is_join($tid,$id){
		$m=M('match_actor');
        $t=$m->where("mid=$id and tid=$tid")->find();
		if(!$t){
			return 'no';     				
	    }else{
	    	return 'yes';	        
	    }
	}

}