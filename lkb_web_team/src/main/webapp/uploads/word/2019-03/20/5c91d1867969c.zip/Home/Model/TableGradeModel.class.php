<?php
namespace Home\Model;
use Think\Model;
class TableGradeModel extends Model {
	//得到信息
    public function getList($tid)
    {
        //查询数据
		$count = $this->where('is_grade="0" and tid = '.$tid)->count();
		$Page = new \Think\Page($count,5);
		$limit = $Page->firstRow.','.$Page->listRows;
		//取得数据
		$data['pn']=$Page->firstRow/5+1;
		$data['page'] = $Page->show();
		
		$sql = "SELECT * FROM table_grade 
		WHERE (`is_grade`='0' and tid = $tid) 
		ORDER BY gid desc
		limit $limit";
		$data['grade'] = $this->query($sql);
		return $data;
    }
    //得到单条信息
    public function getgrade($gid,$tid)
    {	
		$data['grade'] = $this->where('is_grade="0" and gid = '.$gid.' and tid = '.$tid)->find();
		return $data;
    }
}