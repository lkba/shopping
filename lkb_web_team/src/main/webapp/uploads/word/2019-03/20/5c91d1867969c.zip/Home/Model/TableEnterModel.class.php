<?php
namespace Home\Model;
use Think\Model;
class TableEnterModel extends Model {
	/**
	 * 上传文件
	 * @param 
	 * @return 
	 */
	public function upload($tid){
		//准备上传目录
		$file['save'] = date('Y-m/d/');
		$file['path'] = './Public/uploads/word/'.$file['save'];
		file_exists($file['path']) or mkdir($file['path'],0777,true);
		//上传文件
		$Upload = new \Think\Upload(array(
			'maxSize' => 10485760,	
			'exts' => array('zip','rar'),
			'rootPath' => $file['path'],
			'autoSub' => false,
		));
		$rst = $Upload->upload();
		if($rst==false){
			return $Upload->getError();
		}
		//修改数据
		$file['name'] = $rst['cont']['savename'];
		//删除原来的文件
		$this->del($tid);
		//保存数据
		$r=M('table_enter')->where(array('tid'=>$tid))->count();
		if($r==0){
			$this->add(array(
				'prospectus'=> $file['save'].$file['name'],'tid'=>$tid
			));
		}else{
			$this->where("tid=$tid")->save(array(
				'prospectus'=> $file['save'].$file['name'],
			));
		}
		return true;
	}
	/**
	 * 删除关联文件
	 * @param type 
	 * @param type 
	 */
	private function del($tid=0,$file=''){
		$path = './Public/uploads/';
		if($file==''){
			$file = $this->where("tid=$tid")->getField('prospectus');
		}
		if($file && strlen(trim($file))>4){
			//删除文件（空目录仍然存在，需要用其他办法清理空目录）
			unlink($path.'word/'.$file);
		}
	}
	/**
	 * 上传资料
	 * @param 
	 * @return 
	 */
	public function uploadData($tid){
		//准备上传目录
		$file['save'] = date('Y-m/d/');
		$file['path'] = './Public/uploads/data/'.$file['save'];
		file_exists($file['path']) or mkdir($file['path'],0777,true);
		//上传文件
		$Upload = new \Think\Upload(array(
			'maxSize' => 10485760,	
			'exts' => array('zip','rar'),
			'rootPath' => $file['path'],
			'autoSub' => false,
		));
		$rst = $Upload->upload();
		if($rst==false){
			return $Upload->getError();
		}
		//修改数据
		$file['name'] = $rst['cont']['savename'];
		//exit();
		//删除原来的文件
		$this->delData($tid);
		//保存数据
		$this->where("tid=".$tid)->save(array(
			'data'=> $file['save'].$file['name'],
		));
		return true;
	}
	/**
	 * 删除关联资料
	 * @param type 
	 * @param type 
	 */
	private function delData($tid=0,$file=''){
		$path = './Public/uploads/';
		if($file==''){
			$file = $this->where("tid=$tid")->getField('data');
		}
		if($file && strlen(trim($file))>4){
			//删除文件（空目录仍然存在，需要用其他办法清理空目录）
			unlink($path.'data/'.$file);
		}
	}
}