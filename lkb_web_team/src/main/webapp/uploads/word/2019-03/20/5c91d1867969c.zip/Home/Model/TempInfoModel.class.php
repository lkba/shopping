<?php
namespace Home\Model;
use Think\Model;
class TempInfoModel extends Model {
	/**
	 * 上传文件
	 * @param 
	 * @return 
	 */
	public function upload($tpid){
		//准备上传目录
		$file['save'] = date('Y-m/d/');
		$file['path'] = './Public/uploads/word2/'.$file['save'];
		file_exists($file['path']) or mkdir($file['path'],0777,true);
		//上传文件
		$Upload = new \Think\Upload(array(
			'maxSize' => 10485760,	
			'exts' => array('zip','rar'),
			'rootPath' => $file['path'],
			'autoSub' => false,
		));
		$rst = $Upload->upload();
		if($rst==false){
			return $Upload->getError();
		}
		//修改数据
		$file['name'] = $rst['cont']['savename'];
		//保存数据
		$this->where("tpid=$tpid")->save(array(
			'prospectus'=> $file['save'].$file['name'],
		));
		return true;
	}
}