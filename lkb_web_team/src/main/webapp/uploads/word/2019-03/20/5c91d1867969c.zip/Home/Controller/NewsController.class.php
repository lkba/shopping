<?php
namespace Home\Controller;
class NewsController extends CommonController{
	//构造方法
	public function __construct() {
		parent::__construct();
		$tid = $this->userInfo['tid'];
		$is_pass = M('user')->field('is_pass')->where("tid=$tid")->find();	
		if($is_pass['is_pass']!=1){
			$this->error('非法操作');
		}
	}
	public function index(){
		$tid = $this->userInfo['tid'];
		$data=D('News')->getNews($tid);
		//var_dump($data);
        $this->assign($data);
		$this->display();
	}
	public function show(){
		$id=I('get.id');
		$tid = $this->userInfo['tid'];
		$data=M('news_many')->where('id='.$id)->find();
		//var_dump($data);
		$res = M('news_manypop')->where('tid='.$tid.' and nid='.$id)->save(array('is_read'=>'0'));
        $this->assign($data);
		$this->display();
	}
}