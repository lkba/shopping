<?php
namespace Home\Controller;
use Think\Controller;
class LoginController extends Controller{
	//前台登录页
	public function index(){
		if (IS_POST){
			//检查验证码/			
			$rst = $this->checkVerify(I('post.verify'));
			if($rst===false){
			$this->error('验证码错误');
			}
			//检查用户名密码
			$name=I('post.user_name','','trim');
			$pwd=I('post.user_password');
			if(empty($pwd)){
				$this->error('登录失败，密码不能为空');
			}
			$m=D('user');
			$user_info=$m->where("username="."'".$name."'")->find();
			if($user_info==NULL){
				$this->error('登录失败，用户名或密码错误');
			}
			$is_out = $m->where("username="."'".$name."'")->field('is_out,is_pass')->find();
			if($is_out['is_out']==0){
				$this->error('登录失败，账户已注销！');
			}
			$pwd = sha1(md5($pwd).$user_info['salt']);
			if($name==$user_info['username'] && $pwd==$user_info['password']){
				session('username',$user_info['name']);
				session('tid',$user_info['tid']);
				if($is_out['is_pass']==1){
					$this->redirect('Match/index');
				}else{
					$this->redirect('Temp/index');
				}	
			}else{
				$this->error('登录失败，用户名或密码错误');
			}
			return;
		}
		$this->display();
	}	
	//生成验证码
	public function getVerify(){
        ob_end_clean();
        $config =    array(
            'useCurve'=>false,
//            'useImgBg'=>true,
            'codeSet'=>'0123456789',
        );
		$verify = new \Think\Verify($config);
		return $verify->entry();
	}
	//检查验证码
	private function checkVerify($code, $id='') {
		$verify = new \Think\Verify();
		return $verify->check($code,$id);
	}
	//退出系统
	public function logout(){
		session('[destroy]');
		$this->redirect('Index/index');
	}
	//忘记密码
	public function forget(){
		if(IS_POST){
			$this->updatapwd();
			return;
		}
		$this->display();
	}
	public function updatapwd(){		
		$rst = $this->checkVerify(I('post.verify'));
		if($rst===false){
			$this->error('验证码错误');
		}
		$username=I('post.username','','');
		$code=I('post.yz','','trim');
		$code=sha1(md5($code));
		$a=$_COOKIE['c_code'];
		$b=$_COOKIE['c_phome'];

	    //判断是否相等
	    if($code!=$a || $code=='' || empty($a) || $username!=$b){
	    	setcookie("c_code",'');
			setcookie("c_phome",'');
	        $this->error('手机验证错误！');
	    }	
		
		$m = D('user');
		
		$info=$m->where(array('username'=>$username))->count();
		if($info==0){
			setcookie("c_code",'');
			setcookie("c_phome",'');
			$this->error('账号不存在！');
		}
		
		$data['password']=I('post.password');
		$rst = $m->create($data,2);
		if($rst===false){
			setcookie("c_code",'');
			setcookie("c_phome",'');
			$this->error($m->getError);
		}else{
			setcookie("c_code",'');
			setcookie("c_phome",'');
			$info=$m->field('salt')->where(array('username'=>$username))->find();
			//重复名字过滤    
			$new = sha1(md5($data['password']).$info['salt']);
			$r = $m->where(array('username'=>$username))->setField('password',$new);
			if($r!=false){
				$this->success('修改成功！',U('Login/index'));
			}else{
				$this->error('修改失败！');
			}
		}	
	}
	//注册账号
	public function register(){
		if(IS_POST){
			$this->insertID();
			return;
		}
		$this->display();
	}
	public function insertID(){		
		$rst = $this->checkVerify(I('post.verify'));
		if($rst===false){
			$this->error('验证码错误');
		}
		$phome = I('post.username');
		$code=I('post.yz','','');
		$code=sha1(md5($code));
		$a=$_COOKIE['code'];
		$b=$_COOKIE['phome'];
        //判断是否相等
	    if($code!=$a || $code=='' || empty($a) || $phome != $b){
	    	setcookie("code",'');
			setcookie("phome",'');
	        $this->error('手机验证错误！');	
	    }
		
		$m = D('user');
		$rst = $m->create(I('post.'),1);
		if($rst===false){
			setcookie("code",'');
			setcookie("phome",'');
			$this->error($m->getError);
		}else{
			setcookie("code",'');
			setcookie("phome",'');
			$data['username']=I('post.username');
			$data['password']=I('post.password');
			$a = $m->add($data);
			$this->success('注册成功！',U('Login/index'));
		}	
	}
	public function checkIdOnly(){
		$data['username'] = I('post.username','','trim'); //获取查询的用户名
        if($data['username'] == ''){
            $find = '2';//用户名为空
        }else{
            $find = D('user')->where($data)->count(); //查询数据库，是否存在该用户名
        }
		$this->ajaxReturn($find);//返回查询结果，1表示存在，0表示不存在
	}
	public function sjyz(){
		if(IS_POST){
			$phone = I('post.username','','');
			$vcode=mt_rand(000000,999999);
			
			$msg = $this->sendTemplateSMS("$phone", array($vcode, '3'), "418643");
			$vcode=sha1(md5($vcode));
			if($msg=="发送短信成功"){
				setcookie('phone',$phone,time()+180);
				setcookie('code',$vcode,time()+180);
                $this->ajaxReturn(1);
			}else{
				$this->ajaxReturn($msg);
			}	
		}	
	}
	public function sjyz_c(){
		if(IS_POST){
			$phone = I('post.username','','');
			$vcode=mt_rand(000000,999999);
			
			$msg = $this->sendTemplateSMS("$phone", array($vcode, '3'), "418643");
			$vcode=sha1(md5($vcode));
			if($msg=="发送短信成功"){
				setcookie('c_phome',$phone,time()+180);
				setcookie('c_code',$vcode,time()+180);
                $this->ajaxReturn(1);
			}else{
				$this->ajaxReturn($msg);
			}	
		}	
	}
	/*
      * 发送信息给单个团队
      * */
    private function sendTemplateSMS($phone, $datas, $tempId)
    {
        // 初始化REST SDK
        $serverIP = 'app.cloopen.com';
        //请求端口
        $serverPort = '8883';
		//REST版本号
        $softVersion = '2013-12-26';
		//主帐号
        $accountSid = "8aaf070868983fcb0168eb12d32c0981";
		//主帐号Token
        $accountToken = "640fd7ddbc8d4159a2157876412cd2bd";
		//应用Id
        $appId = "8aaf070868983fcb0168eb154b68098c";
		//    Vendor('Rest.Rest');
        $rest = new \Think\SMS("$serverIP", "$serverPort", "$softVersion");

        $rest->setAccount("$accountSid", "$accountToken");
        $rest->setAppId("$appId");
        // 发送模板短信
//    echo "Sending TemplateSMS to $phone <br/>";
        $result = $rest->sendTemplateSMS($phone, $datas, $tempId);
        if ($result == NULL) {
            return "result error!";
//         break;
            exit();
        }
        if ($result->statusCode != 0) {
        	return $result->statusMsg;
//          echo "发送短信失败<br/>";
//          echo "error code :" . $result->statusCode . "<br>";
//          echo "error msg :" . $result->statusMsg . "<br>";
            //TODO 添加错误处理逻辑
        } else {
            return "发送短信成功";
            // 获取返回信息
            $smsmessage = $result->TemplateSMS;
            //echo "dateCreated:" . $smsmessage->dateCreated . "<br/>";
            //echo "smsMessageSid:" . $smsmessage->smsMessageSid . "<br/>";
            //TODO 添加成功处理逻辑
        }
    }
	
	
	
	
	
	
	
	
	
	
	
	//申请入驻
	public function sub(){
		if (IS_POST){
			$this->insertAction();
			return;
		}
		$this->display();
	}
	//修改-处理表单
	private function insertAction($tid){
				
		$data = I('post.','','trim');
		
		
		//修改基本信息
		M('temp_info')->create();
		$rst = M('temp_info')->add();
		if($rst==false){
			$this->error("提交失败！");
		}
		
		//修改老师信息
		foreach($data['tname'] as $key => $v){
			$teacher = M("temp_teacher"); // 实例化User对象	
			$data2 = array('tname'=>$data['tname'][$key],'tdepartment'=>$data['tdepartment'][$key],'position'=>$data['position'][$key],'field'=>$data['field'][$key],'tpid'=>$rst);
			$teacher->add($data2);		
		}
		
		//修改成员信息
		foreach($data['dname'] as $key => $v){
			$teammate = M("temp_teammate");
			$data3 = array('dname'=>$data['dname'][$key],'dsex'=>$data['dsex'][$key],'ddepartment'=>$data['ddepartment'][$key],'dprofessional'=>$data['dprofessional'][$key],'dphone'=>$data['dphone'][$key],'demail'=>$data['demail'][$key],'tpid'=>$rst);
			$teammate->add($data3);
		}
		//保存上传文件
		if(!empty($_FILES['cont']['name'])){
			$rst2 = D('temp_info')->upload($rst);
			if($rst2!=true){
				$this->error("提交失败！");
			}
		}		
		//跳转
		$this->success('提交成功，等待审核！',U('Login/sub'));
	}
}