<?php

namespace Home\Model;

use Think\Model;

class SendSMSModel extends Model
{
    /*
      * 发送信息给单个团队
      * */
    private function sendTemplateSMS($phone, $datas, $tempId)
    {
        // 初始化REST SDK
        $serverIP = 'app.cloopen.com';
        //请求端口
        $serverPort = '8883';
		//REST版本号
        $softVersion = '2013-12-26';
		//主帐号
        $accountSid = "8aaf070868983fcb0168eb12d32c0981";
		//主帐号Token
        $accountToken = "640fd7ddbc8d4159a2157876412cd2bd";
		//应用Id
        $appId = "8aaf070868983fcb0168eb154b68098c";
		//    Vendor('Rest.Rest');
        $rest = new \Think\SMS("$serverIP", "$serverPort", "$softVersion");

        $rest->setAccount("$accountSid", "$accountToken");
        $rest->setAppId("$appId");
        // 发送模板短信
//    echo "Sending TemplateSMS to $phone <br/>";
        $result = $rest->sendTemplateSMS($phone, $datas, $tempId);
        if ($result == NULL) {
            echo "result error!";
//         break;
            exit();
        }
        if ($result->statusCode != 0) {
            echo "发送短信失败<br/>";
            echo "error code :" . $result->statusCode . "<br>";
            echo "error msg :" . $result->statusMsg . "<br>";
            //TODO 添加错误处理逻辑
        } else {
            echo "发送短信成功<br/>";
            // 获取返回信息
            $smsmessage = $result->TemplateSMS;
            echo "dateCreated:" . $smsmessage->dateCreated . "<br/>";
            echo "smsMessageSid:" . $smsmessage->smsMessageSid . "<br/>";
            //TODO 添加成功处理逻辑
        }
    }
}