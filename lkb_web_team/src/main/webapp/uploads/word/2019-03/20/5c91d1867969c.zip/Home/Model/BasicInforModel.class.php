<?php
namespace Home\Model;
use Think\Model;
class BasicInforModel extends Model {
	/**
	 * 上传文件
	 * @param 
	 * @return 
	 */
	public function uploadThumb($tid){
		//准备上传目录
		$file['temp'] = './Public/uploads/temp/';
		file_exists($file['temp']) or mkdir($file['temp'],0777,true);
		//上传文件
		$Upload = new \Think\Upload(array(
			'exts' => array('jpg','gif','png','bmp'),
			'rootPath' => $file['temp'],
			'autoSub' => false,
		));
		$rst = $Upload->upload();
		if($rst===false){
			return $Upload->getError();
		}
		//生成文件信息
		$file['name'] = $rst['thumb']['savename'];
		$file['save'] = date('Y-m/d/');
		$file['path'] = './Public/uploads/logo/'.$file['save'];
		//创建保存目录
		file_exists($file['path']) or mkdir($file['path'],0777,true);
		//生成缩略图
		$Image = new \Think\Image(); 
		$Image->open($file['temp'].$file['name']);
		$Image->thumb(100,100,1)->save($file['path'].$file['name']);//大图 $Image->thumb （width,height, 1 等比例缩放类型  2 缩放后填充类型  3 居中裁剪类型  4 左上角裁剪类型   5 右下角裁剪类型  6 固定尺寸缩放类型
		//删除临时文件
		unlink($file['temp'].$file['name']);
		//删除原来的图片文件
		$this->delImage($tid);
		
		$r=M('basic_infor')->where(array('tid'=>$tid))->count();
		//保存缩略图
		if($r==0){
			$this->add(array(
				'logo'=> $file['save'].$file['name'],'tid'=>$tid
			));
		}else{
			$this->where("tid=$tid")->save(array(
				'logo'=> $file['save'].$file['name'],
			));
		}
		return $file['save'].$file['name'];
	}
	/**
	 * 删除关联图片文件
	 * @param type 
	 * @param type 
	 */
	private function delImage($tid=0,$file=''){
		$path = './Public/uploads/';
		if($file==''){
			$file = $this->where("tid=$tid")->getField('logo');
		}
		if($file && strlen(trim($file))>4){
			//删除文件（空目录仍然存在，需要用其他办法清理空目录）
			unlink($path.'logo/'.$file);
		}
	}
}
