<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller{
	public function index(){
		$m = D('match');
		$data = $m->getMatchs();
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
	public function show(){
		$id = I('get.id');
		$m = D('match');
		$data['match'] = $m->getMatch($id);
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
}