<?php
namespace Home\Controller;
class SetController extends CommonController{
	public function index(){
		$this->display();
	}
	public function set_m(){
		$tid = $this->userInfo['tid'];
		if (IS_POST){
			$this->reviseAction($tid);
			return;
		}
		$this->display();
	}
	//修改密码
	private function reviseAction($tid){
		$usedpwd = I("post.used");//旧
		$newpwd = I("post.new");//new
		if(empty($newpwd)){
				$this->error('修改失败，密码不能为空');
			}
		$againpwd = I("post.again");//again
		$m=M('user');//用户数据库
		
		
        $info=$m->where("tid='".$tid."'")->find();
		//重复名字过滤    
		$used = sha1(md5($usedpwd).$info['salt']);

		if($used == $info['password']){
            if($newpwd == $againpwd){
                $md5_password = sha1(md5($newpwd).$info['salt']);
                $result = $m->where('tid='.$tid)->save(['password' => $md5_password]);
                if($result){
                    return $this->redirect('Set/set_m/c/success');$this->success('修改成功啦!',"set_m/c/success",2);
                }else{
                    return $this->error('密码未改动，修改失败!');
                }
            }else{
                return $this->error('密码不一致，请再次输入!');
            }
        }else{
            return $this->error('原密码输入错误!');
        }		
	}
}