<?php
namespace Admin\Model;
use Think\Model;
class TeamModel extends Model {
	
}
