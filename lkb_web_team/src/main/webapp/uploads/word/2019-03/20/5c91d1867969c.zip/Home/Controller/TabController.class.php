<?php
namespace Home\Controller;
class TabController extends CommonController{
	//构造方法
	public function __construct() {
		parent::__construct();
		$tid = $this->userInfo['tid'];
		$is_pass = M('user')->field('is_pass')->where("tid=$tid")->find();	
		if($is_pass['is_pass']!=1){
			$this->error('非法操作');
		}
	}
	public function index(){
		$this->display();
	}
	//自查表提交
	public function Isub(){
		$tid = $this->userInfo['tid'];
		$sid = I('get.sid');
		$data['self'] = M('table_self')->where("sid=$sid")->find();
		if($data['self']['is_sub']==1){
				return $this->ajaxReturn(array('msg'=>'已提交！'));
		}
		$res = M('table_self')->where(array('sid' => $sid, 'tid' => $tid))->setField(array('is_sub' => 1));
		if($res==false){
			$this->ajaxReturn(array('msg'=>'提交失败！'));
		}else{
			$this->ajaxReturn(array('flag'=>true));			
		}
	}
	//自查表list
	public function ITab_list(){
		$tid = $this->userInfo['tid'];
		$m = D('table_self');
		$data = $m->getList($tid);
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
	//自查表查看
	public function ITab(){
		$tid = $this->userInfo['tid'];
		$sid = I('get.sid');
		$m = D('user');
		$data["basic"] = $m->getbList($tid);
		$data["user"] = $m->getuList($tid);
		$data["teacher"] = $m->gettList($tid);
		$data["team"] = $m->getteamList($tid);
		$data['self'] = M('table_self')->where("sid=$sid and tid=$tid")->find();
		$data['len'] = count($data["teacher"])*2;
		$data['len2'] = count($data["team"])+1;
		if(empty($data["teacher"])){
			$data["teacher"][0]['name']='无';
			$data["teacher"][0]['department']='无';
			$data["teacher"][0]['position']='无';
			$data["teacher"][0]['field']='无';
			$data['len'] = 2;
		}
		if(empty($data["team"])){
			$data["team"][0]['name']='无';
			$data["team"][0]['sex']='无';
			$data["team"][0]['department']='无';
			$data["team"][0]['professional']='无';
			$data["team"][0]['phone']='无';
			$data["team"][0]['email']='无';
			$data['len2'] = 2;
		}
		$data['self'] = M('table_self')->where("sid=$sid and tid=$tid")->find();
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
	//自查表修改
	public function reITab(){
		$tid = $this->userInfo['tid'];
		$sid = I('get.sid');
		$m = D('user');
		$data["basic"] = $m->getbList($tid);
		$data["user"] = $m->getuList($tid);
		$data["teacher"] = $m->gettList($tid);
		$data["team"] = $m->getteamList($tid);
		$data['self'] = M('table_self')->where("sid=$sid and tid=$tid")->find();
		$data['len'] = count($data["teacher"])*2;
		$data['len2'] = count($data["team"])+1;
		if(empty($data["teacher"])){
			$data["teacher"][0]['name']='无';
			$data["teacher"][0]['department']='无';
			$data["teacher"][0]['position']='无';
			$data["teacher"][0]['field']='无';
			$data['len'] = 2;
		}
		if(empty($data["team"])){
			$data["team"][0]['name']='无';
			$data["team"][0]['sex']='无';
			$data["team"][0]['department']='无';
			$data["team"][0]['professional']='无';
			$data["team"][0]['phone']='无';
			$data["team"][0]['email']='无';
			$data['len2'] = 2;
		}
		//var_dump($data);
		if (IS_POST){	
			if($data['self']['is_sub']==1){
				return $this->error("已提交！");
			}
			$out = M('table_self');
            $data2 = $out->create();

            $res = $out->where(array('sid' => $sid,'tid' => $tid))->setField($data2);

			if($res==false){
				return $this->error("修改信息失败！");
			}else{
				return $this->redirect('Tab/reITab/c/success');
				//return $this->success("修改信息成功","reITab/c/success",2);			
			}
		}
		$this->assign($data);
		$this->display();
	}
	
	//评分表list
	public function GTab_list(){
		$tid = $this->userInfo['tid'];
		$m = D('table_grade');
		$data= $m->getList($tid);
		
		$this->assign($data);
		$this->display();
	}

	//评分表查看
	public function GTab(){
		$tid = $this->userInfo['tid'];
		$gid = I('get.gid');
		$m = D('table_grade');
		$data= $m->getgrade($gid,$tid);
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
	
	//退出表list
	public function OutTab_list(){
		$tid = $this->userInfo['tid'];
		$m = M('table_out');
		$data['data'] = $m->where("tid=$tid")->order('oid desc')->select();
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}

	//退出表查看
	public function OutTab(){
		$tid = $this->userInfo['tid'];
		$oid = I('get.oid');
		$m = D('user');
		$data["basic"] = $m->getbList($tid);
		$data["user"] = $m->getuList($tid);
		$data['out'] = M('table_out')->where("oid=$oid and tid=$tid")->find();
		//var_dump($data);
		$this->assign($data);
		$this->display();
	}
	//退出提交
	public function sub(){
		$tid = $this->userInfo['tid'];
		$oid = I('get.oid');
		$data['out'] = M('table_out')->where("oid=$oid")->find();
		if($data['out']['is_sub']==1){
				return $this->ajaxReturn(array('msg'=>'已提交！'));
		}
		$res = M('table_out')->where(array('oid' => $oid,'tid'=>$tid))->save(array('is_sub' => 1));
		if($res==false){
			return $this->ajaxReturn(array('msg'=>'提交失败！'));
		}else{
			return $this->ajaxReturn(array('flag'=>true));			
		}
	}
	//退出表add
	public function addOutTab(){
		$tid = $this->userInfo['tid'];
		$m = D('user');
		$data["basic"] = $m->getbList($tid);
		$data["user"] = $m->getuList($tid);
		$data['tid'] = $tid;
		//var_dump($data);
		if (IS_POST){	
			$out = M('table_out');
            $data = $out->create();
            if($data['out_reason'] != null){
            	$data['out_reason'] = implode(',',$data['out_reason']);
            }
            //var_dump($data);
            //exit();
            $res = $out->add($data);
			if($res==false){
				return $this->error("添加申请失败！");
			}else{
				return $this->redirect('Tab/addOutTab/c/success');	
			}
		}
		$this->assign($data);
		$this->display();
	}
	//退出表编辑
	public function reOutTab(){
		$tid = $this->userInfo['tid'];
		$oid = I('get.oid');
		$m = D('user');
		$data["basic"] = $m->getbList($tid);
		$data["user"] = $m->getuList($tid);
		$data['out'] = M('table_out')->where("oid=$oid and tid = $tid")->find();
		$data['other'] = explode(',',$data['out']['out_reason']);
		foreach ($data['other'] as $k=>$v){
			if($v =='项目停止' || $v =='项目变更' || $v =='团队成员解散' || $v =='公司业务发展需要' || $v =='场地受限'){				
				$data['other'] = null;
			}else{
				$data['other'] = $v;
			}
		}
		//var_dump($data);
		if (IS_POST){	
			if($data['out']['is_sub']==1){
				return $this->error("已提交！");
			}
			$out = M('table_out');
            $data = $out->create();
            if($data['out_reason'] != null){
            	$data['out_reason'] = implode(',',$data['out_reason']);
            }

            $res = $out->where(array('oid' => $oid,'tid' => $tid))->setField($data);

			if($res==false){
				return $this->error("修改信息失败！");
			}else{
				return $this->redirect('Tab/reOutTab/c/success');
				//return $this->success("修改信息成功","reOutTab/c/success",2);			
			}
		}
		$this->assign($data);
		$this->display();
	}
	
}