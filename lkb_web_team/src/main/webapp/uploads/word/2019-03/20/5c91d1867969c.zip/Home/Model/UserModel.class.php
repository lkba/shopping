<?php
namespace Home\Model;
use Think\Model;
class UserModel extends Model {
	protected $insertFields = 'username,name,age,sex,department,professional,salt,time,phone,email,password';
	protected $updateFields = 'username,name,age,sex,department,professional,salt,time,phone,email,password,is_out,is_sub,is_pass';
	protected $_validate = array(
		array('username','require','用户名不能为空',0,'',3),
		array('username', 11, '手机号码格式不正确', 0, 'length', 3),
		array('username', '', '账号已经存在', 0, 'unique', 3),
		array('name','/^[0-9a-zA-Z_\x{4e00}-\x{9fa5}]+$/u','用户名只能是汉字、字母、数字、下划线。',0,'',3),
		array('password','require','密码不能为空',0,'',3),
		array('password','6,20','密码位数不合法（6~20位）',0,'length',3),
		array('phone', 11, '手机号码格式不正确', 0, 'length', 2),
		//......实际项目需要更多的验证规则，读者可以自行实现。
	);
	//校验用户名和密码
	public function checkUser($username,$pwd) {
		$data = $this->field('mid,username,password,salt,is_out,name')->where(array('email'=>$email))->find();
		if($data===null){
			return '用户名不存在';
		}
		if($data['is_out']==0){
			return '账号已注销！';
		}
		if($data['password']==$this->password($pwd,$data['salt'])){
			//密码正确
			session('name',$data['name']);
			session('user_id',$data['tid']);
			session_regenerate_id();
			return true;
		}
		return '密码错误';
	}
	//密码加密函数
	private function password($pwd,$salt){
		return sha1(md5($pwd).$salt);
	}
	//插入数据前的回调方法
	protected function _before_insert(&$data,$option) {
		$data['salt'] = substr(uniqid(), -6);
		$data['password'] = $this->password($data['password'],$data['salt']);
	}
	
	
	
	
	//团队信息index
	public function getbList($tid){
		$basic = C('DB_PREFIX').'basic_infor';  //连接前缀
		$teacher =  C('DB_PREFIX').'teacher';
		$teammate = C('DB_PREFIX').'teammate';
		$user =  C('DB_PREFIX').'user';
		$sql = "select * from $basic
				where tid=$tid ";
		return $this->query($sql);
	}
	public function getuList($tid){
		$user =  C('DB_PREFIX').'user';
		$sql = "select * from $user
				where tid=$tid ";
		return $this->query($sql);
	}
	public function gettList($tid){
		$teacher =  C('DB_PREFIX').'teacher';
		$sql = "select * from $teacher 
				where tid=$tid ";
		return $this->query($sql);
	}
	public function getteamList($tid){
		$teammate = C('DB_PREFIX').'teammate';
		$sql = "select * from $teammate 
				where tid=$tid ";
		return $this->query($sql);
	}
	public function geteList($tid){
		$enter= C('DB_PREFIX').'table_enter';
		$sql = "select * from $enter 
				where tid=$tid ";
		return $this->query($sql);
	}
}
